package com.servletsample;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class MySample extends HttpServlet {


    public void init() {
        System.out.println("Inside init");
    }

    @Override
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        System.out.println("inside do get");
        System.out.println(request.getParameter("name") + " " + request.getParameter("id"));
        final RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/jsp/my-sample-home.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response) {
        System.out.println("inside do post");
    }

    @Override
    public void destroy() {
        System.out.println("destroy");
    }

}
