package com.springmvc;


import com.springmvc.model.Employee;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;


@Controller
public class ExceptionDemoController {

    @ResponseBody
    @RequestMapping("/get-employee1")
    public Employee getEmployee(final Employee employee) {
        int c = 22/0;
        if(employee.getAge() == -1){
            throw new IllegalArgumentException();
        }

        return employee;
    }

    @ExceptionHandler(Exception.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public String onException(final Exception ex){
        System.out.println(ex);
        return "You have some exception";
    }

}
