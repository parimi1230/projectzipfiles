package com.springmvc;


import com.springmvc.model.Employee;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;

@Controller
public class DemoController {


    // http://localhost:8089/sample/do-get1?name=Rakesh&id=12345
    @ResponseBody
    @RequestMapping(value = "/do-get1", method = RequestMethod.GET)
    public Employee doGet(final Employee employee) {
        employee.setAge(25);
        return employee;
    }

    @RequestMapping(value = "/employees/{myName}", method = RequestMethod.GET)
    public void doGet1(@PathVariable final String myName) {
        System.out.println("Do get 2" + myName);
    }

    @RequestMapping(value = "/do-post1", method = RequestMethod.POST)
    public void doPost1() throws IOException {
        System.out.println("Do post 1");
    }

    @RequestMapping(value = "/do-get-with-view", method = RequestMethod.GET)
    public void doGetWithView(final ModelAndView modelAndView) {
        System.out.println("do get with view");
        modelAndView.setViewName("my-sample-home");
    }


    @RequestMapping(value = "/do-get-with-view1", method = RequestMethod.GET)
    public void doGetWithView2(final ModelAndView modelAndView) {
        System.out.println("do get with view");
        modelAndView.setViewName("sample2");
    }

}
