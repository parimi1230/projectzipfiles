package com.sample.dependencyinjection;

/**
 * Created by pparimi on 26-11-2018.
 */
public interface IAddress {
}
